const { WebcastPushConnection } = require('tiktok-live-connector');

const express = require('express');
const app = express();
const http = require('http');
const server = http.createServer(app);
const { Server } = require("socket.io");
const io = new Server(server);


// Username of someone who is currently live
let tiktokUsername = "niightporo";

// Create a new wrapper object and pass the username
let tiktokLiveConnection = new WebcastPushConnection(tiktokUsername);

// Connect to the chat (await can be used as well)
tiktokLiveConnection.connect().then(state => {
    console.info(`Connected to roomId ${state.roomId}`);
}).catch(err => {
    console.error('Failed to connect', err);
})

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

io.on('connection', (socket) => {
    console.log(`User ${socket.id} connected`);
});

tiktokLiveConnection.on('chat', data => {
    //console.log(`${data.uniqueId}: ${data.comment}`);
    io.emit('message', `${data.uniqueId}: ${data.comment}`);
});

tiktokLiveConnection.on('follow', (data) => {
    //console.log(data.uniqueId, "followed!");
    io.emit('follow', `${data.uniqueId} ha lasciato il follow!`)
});

tiktokLiveConnection.on('gift', data => {
    //console.log(`${data.uniqueId} (userId:${data.userId}) sends ${data.giftId}`);
    io.emit('gift', `${data.uniqueId} ha inviato ${data.giftId}!`);
});

server.listen(3000, () => {
    console.log("Listening on http://localhost:3000");
});